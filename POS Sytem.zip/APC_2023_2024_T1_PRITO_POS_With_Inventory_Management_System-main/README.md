# APC_2023_2024_T1_PRITO_POS_With_Inventory_Management_System

Team ZWP Microsoft Sway
Project: Prito Corner Food Stall: POS with Inventory Management System

Link: https://sway.office.com/SFeV5JhvFbcEge2p


